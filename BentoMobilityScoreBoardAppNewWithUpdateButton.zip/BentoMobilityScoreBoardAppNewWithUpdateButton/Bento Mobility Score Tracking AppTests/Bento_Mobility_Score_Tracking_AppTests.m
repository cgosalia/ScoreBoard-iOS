//
//  Bento_Mobility_Score_Tracking_AppTests.m
//  Bento Mobility Score Tracking AppTests
//
//  Created by Ravi Varsha Cheemanahalli Gopalakrishna on 2/8/14.
//  Copyright (c) 2014 Ravi Varsha Cheemanahalli Gopalakrishna. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Bento_Mobility_Score_Tracking_AppTests : XCTestCase

@end

@implementation Bento_Mobility_Score_Tracking_AppTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
