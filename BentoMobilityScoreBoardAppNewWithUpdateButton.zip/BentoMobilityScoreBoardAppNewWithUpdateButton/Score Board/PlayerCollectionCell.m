//
//  PlayerCollectionCell.m
//  Bento Mobility Score Tracking App
//
//  Created by Ravi Varsha Cheemanahalli Gopalakrishna on 3/15/14.
//  Copyright (c) 2014 Ravi Varsha Cheemanahalli Gopalakrishna. All rights reserved.
//

#import "PlayerCollectionCell.h"

@implementation PlayerCollectionCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
//        UIView *insetView = [[UIView alloc] initWithFrame:CGRectInset(self.bounds, self.bounds.size.width/8, self.bounds.size.height/8)];
//        [self.contentView addSubview:insetView];
//        
//        self.layer.shouldRasterize = YES;
//        self.playerName = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, insetView.frame.size.width, insetView.frame.size.height)];
//        self.playerName.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
//        self.playerName.textAlignment = NSTextAlignmentCenter;
//        self.playerName.numberOfLines = 3;
//        self.playerName.lineBreakMode = NSLineBreakByWordWrapping;
//        float dim = MIN(self.playerName.bounds.size.width, self.playerName.bounds.size.height);
//        self.playerName.clipsToBounds = YES;
//        self.playerName.layer.cornerRadius = dim/8;
//        self.playerName.layer.opacity = 0.7;
//        self.playerName.layer.borderColor = [UIColor darkGrayColor].CGColor;
//        self.playerName.layer.borderWidth = 1.0;
//        self.playerName.font = [UIFont systemFontOfSize:dim/6];
//        
//        self.playerName.backgroundColor = [UIColor lightGrayColor];
//        
//        
//        self.playerScore = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, insetView.frame.size.width, insetView.frame.size.height)];
//        self.playerScore.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
//        self.playerScore.textAlignment = NSTextAlignmentCenter;
//        self.playerScore.numberOfLines = 3;
//        self.playerScore.lineBreakMode = NSLineBreakByWordWrapping;
//        float dim2 = MIN(self.playerScore.bounds.size.width, self.playerScore.bounds.size.height);
//        self.playerScore.clipsToBounds = YES;
//        self.playerScore.layer.cornerRadius = dim2/8;
//        self.playerScore.layer.opacity = 0.7;
//        self.playerScore.layer.borderColor = [UIColor darkGrayColor].CGColor;
//        self.playerScore.layer.borderWidth = 1.0;
//        self.playerScore.font = [UIFont systemFontOfSize:dim2/6];
//        
//        self.playerScore.backgroundColor = [UIColor lightGrayColor];
//        [insetView addSubview:self.playerScore];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
